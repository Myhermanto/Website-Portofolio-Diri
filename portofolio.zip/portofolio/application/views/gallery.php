<!DOCTYPE html>
<html lang="en">
  <head>
    <title>My Gallery</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo base_url().'assets/css/open-iconic-bootstrap.min.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/animate.css'?>">
    
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/owl.carousel.min.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/owl.theme.default.min.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/magnific-popup.css'?>">

    <link rel="stylesheet" href="<?php echo base_url().'assets/css/aos.css'?>">

    <link rel="stylesheet" href="<?php echo base_url().'assets/css/ionicons.min.css'?>">

    <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap-datepicker.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/jquery.timepicker.css'?>">

    
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/flaticon.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/icomoon.css'?>">
	<link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css'?>">

  </head>
  <body>

	<div id="colorlib-page">
        <a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle"><i></i></a>
        
	<?php $this->load->view('header') ?>

		<div id="colorlib-main">
			<section class="ftco-section ftco-bread">
				<div class="container">
					<div class="row no-gutters slider-text justify-content-center align-items-center">
	          <div class="col-md-8 ftco-animate">
	            <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo base_url().'Gallery'?>">Home</a></span> <span>Gallery</span></p>
	            <h1 class="bread">My Gallery</h1>
	          </div>
	        </div>
				</div>
			</section>
			<section class="ftco-section-3">
				<div class="photograhy">
					<div class="row">
						<div class="col-md-4 ftco-animate">
							<a href="images/image_1.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_1.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 01</h3>
									<span class="tag">Model</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_2.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_2.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 02</h3>
									<span class="tag">Nature</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_3.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_3.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 03</h3>
									<span class="tag">Fashion</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_4.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_4.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 04</h3>
									<span class="tag">Travel</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_5.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_5.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 05</h3>
									<span class="tag">Travel</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_6.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_6.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 06</h3>
									<span class="tag">Travel</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_7.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_7.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 07</h3>
									<span class="tag">Fashion, Model</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_8.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_8.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 08</h3>
									<span class="tag">Nature</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_9.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_9.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 09</h3>
									<span class="tag">Technology</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_10.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_10.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 10</h3>
									<span class="tag">Model</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_11.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_11.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 11</h3>
									<span class="tag">Fashion</span>
								</div>
							</a>
						</div>
						<div class="col-md-4 ftco-animate">
							<a href="images/image_12.jpg" class="photography-entry img image-popup d-flex justify-content-start align-items-end" style="background-image: url(<?php echo base_url().'assets/images/image_12.jpg'?>);">
								<div class="overlay"></div>
								<div class="text ml-4 mb-4">
									<h3>Photo 12</h3>
									<span class="tag">Photography</span>
								</div>
							</a>
						</div>
					</div>
				</div>
            </section>

            <?php $this->load->view('footer') ?>

		</div><!-- END COLORLIB-MAIN -->
	</div><!-- END COLORLIB-PAGE -->

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="<?php echo base_url().'assets/js/jquery.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/jquery-migrate-3.0.1.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/popper.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/bootstrap.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/jquery.easing.1.3.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/jquery.waypoints.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/jquery.stellar.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/owl.carousel.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/jquery.magnific-popup.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/aos.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/jquery.animateNumber.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/bootstrap-datepicker.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/jquery.timepicker.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/scrollax.min.js'?>"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="<?php echo base_url().'assets/js/google-map.js'?>"></script>
  <script src="<?php echo base_url().'assets/js/main.js'?>"></script>
    
  </body>
</html>